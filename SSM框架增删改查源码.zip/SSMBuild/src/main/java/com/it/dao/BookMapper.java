package com.it.dao;

import com.it.pojo.Books;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author wsx
 * @create 2020-06-22-10:46
 */
@SuppressWarnings("All")
public interface BookMapper {
	//增加
	int addBook(Books books);

	//删除
	int deleteBookById(@Param("bookId") int id);

	//查找
	Books queryBookById(@Param("bookId") int id);

	//修改
	int updateBooks(Books books);

	//显示全部书籍
	List<Books> queryAllBooks();

	//根据书名查询
	Books queryBookByName(@Param("bookName") String bookName);
}
