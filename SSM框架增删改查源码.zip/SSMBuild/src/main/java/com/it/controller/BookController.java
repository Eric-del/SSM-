package com.it.controller;

import com.it.pojo.Books;
import com.it.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;

/**
 * @author wsx
 * @create 2020-06-22-13:56
 */
@SuppressWarnings("all")
@Controller
@RequestMapping("/book")
public class BookController {

	@Autowired
	@Qualifier("BookServiceImpl")
	private BookService bookService;

	@RequestMapping("/allBook")
	public String list(Model model){
		List<Books> books = bookService.queryAllBooks();
		model.addAttribute("list",books);
		return "allBook";
	}

	//跳转到添加书籍页面
	@RequestMapping("/toaddBook")
	public String toaddBook(Model model){
		return "addBook";
	}

	//添加书籍
	@RequestMapping("/addBook")
	public String addBook(Books books){
		int i = bookService.addBook(books);
		return "redirect:/book/allBook";
	}

	//跳转到修改书籍页面
	@RequestMapping("/toUpdatePage")
	public String toUpdatePage(int id,Model model){
		Books books = bookService.queryBookById(id);
		model.addAttribute("book",books);
		return "updateBook";
	}

	//修改书籍
	@RequestMapping("/updateBooks")
	public String updateBook(Books books){
		int i = bookService.updateBooks(books);
		return "redirect:/book/allBook";
	}

	//删除书籍
	@RequestMapping("/deleteBook")
	public String deleteBook(int id){
		int i = bookService.deleteBookById(id);
		return "redirect:/book/allBook";
	}

	//查询书籍
	@RequestMapping("/queryBook")
	public String queryBook(String queryBookName,Model model){
		Books books = bookService.queryBookByName(queryBookName);
		List<Books> list=new ArrayList<Books>();
		list.add(books);
		if(books==null){
			list = bookService.queryAllBooks();
			model.addAttribute("error","未查到");
		}
		model.addAttribute("list",list);
		return "allBook";
	}
}
