package com.it.service;

import com.it.pojo.Books;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wsx
 * @create 2020-06-22-11:12
 */
@SuppressWarnings("all")
public interface BookService {
	//增加
	int addBook(Books books);

	//删除
	int deleteBookById(int id);

	//查找
	Books queryBookById(int id);

	//修改
	int updateBooks(Books books);

	//显示全部书籍
	List<Books> queryAllBooks();

	//根据书名查询
	Books queryBookByName(String bookName);
}
