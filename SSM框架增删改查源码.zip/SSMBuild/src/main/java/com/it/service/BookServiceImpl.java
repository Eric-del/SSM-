package com.it.service;

import com.it.dao.BookMapper;
import com.it.pojo.Books;

import java.util.List;

/**
 * @author wsx
 * @create 2020-06-22-11:13
 */
public class BookServiceImpl implements BookService {
	//业务层调dao层 组合dao层
	private BookMapper bookMapper;

	//设置set方法spring即可托管
	public void setBookMapper(BookMapper bookMapper) {
		this.bookMapper = bookMapper;
	}

	public int addBook(Books books) {
		return bookMapper.addBook(books);
	}

	public int deleteBookById(int id) {
		return bookMapper.deleteBookById(id);
	}

	public Books queryBookById(int id) {
		return bookMapper.queryBookById(id);
	}

	public int updateBooks(Books books) {
		return bookMapper.updateBooks(books);
	}

	public List<Books> queryAllBooks() {
		return bookMapper.queryAllBooks();
	}

	public Books queryBookByName(String bookName) {
		return bookMapper.queryBookByName(bookName);
	}
}
