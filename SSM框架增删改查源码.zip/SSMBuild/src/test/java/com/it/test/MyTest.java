package com.it.test;

import com.it.pojo.Books;
import com.it.service.BookServiceImpl;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

/**
 * @author wsx
 * @create 2020-06-22-14:20
 */
public class MyTest {
	@Test
	public void test(){
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		BookServiceImpl serviceImpl = (BookServiceImpl) context.getBean("BookServiceImpl");
		List<Books> books = serviceImpl.queryAllBooks();
		for (Books book : books) {
			System.out.println(book);
		}
	}

}
